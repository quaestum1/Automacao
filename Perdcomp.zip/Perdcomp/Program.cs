﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Perdcomp
{
    public class Program
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]

        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);

        private const uint MOUSEEVENTTF_LEFTDOWN = 0x02;
        private const uint MOUSEEVENTTF_LEFTUP = 0x04;

        public static void DoMouseClick()
        {
            uint X = (uint)Cursor.Position.X;
            uint Y = (uint)Cursor.Position.Y;
            mouse_event(MOUSEEVENTTF_LEFTDOWN | MOUSEEVENTTF_LEFTUP, X, Y, 0, 0);
        }

        static readonly MySqlConnection mySql = new MySqlConnection("server=localhost; user id=root; database=manserv; password=");
        static readonly MySqlConnection mySqlUpd = new MySqlConnection("server=localhost; user id=root; database=manserv; password=");
        public static IWebDriver driver;
        static void Main()
        {
            mySql.Open();
            MySqlCommand myCmd = new MySqlCommand("select filial, coligada, id_certificado from empresa_filial where filial not in (select cnpj from log_pedcomp where dt_fim is not null)", mySql);
            MySqlCommand myCmdUpd = new MySqlCommand("",mySqlUpd);
            MySqlDataReader myRead = myCmd.ExecuteReader();
            string filial, coligada, coligada_anterior = string.Empty;
            int id_cert;
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("start-maximized");

            while (myRead.Read()) {
                coligada = myRead[1].ToString();
                filial = myRead[0].ToString();
                id_cert = Convert.ToInt32(myRead[2]);
                if ((coligada_anterior == string.Empty) || (coligada != coligada_anterior))
                {
                    // Fechar chrome e fazer login
                    Process.Start("taskkill", "/f /im chrome.exe").WaitForExit();
                    driver = new ChromeDriver(options);
                    driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
                    try
                    {
                        driver.Navigate().GoToUrl("https://cav.receita.fazenda.gov.br/autenticacao/login");
                    } catch (Exception)
                    {
                        driver.Navigate().GoToUrl("https://cav.receita.fazenda.gov.br/autenticacao/login");
                    }
                    
                    driver.FindElement(By.XPath("/html/body/div[2]/div/div[2]/div[2]/form/div/p[2]")).Click();
                    Cursor.Position = new Point(926, 691);
                    DoMouseClick(); // Clica no link que abre janela para selecionar o certificado
                    Seleciona_Certificado(id_cert);
                }
                // Verificar se tem mensagem caixa postal
                try
                {
                    driver.FindElement(By.XPath("/html/body/div[7]/div[11]/div/button")).Click();
                    driver.FindElement(By.XPath("/html/body/div[2]/a[2]")).Click();
                    try
                    {
                        driver.FindElement(By.XPath("/html/body/div[7]/div[11]/div/button"));
                        Console.WriteLine("Mensagens na Caixa Postal.");
                        driver.Close();
                        mySqlUpd.Open();
                        myCmdUpd.CommandText = "insert into log_pedcomp (cnpj, ano_calendario, dt_inicio, obs) values ('" + filial + "', '2020', now(), 'Mensagem Caixa postal')";
                        Console.WriteLine(myCmdUpd.CommandText);
                        myCmdUpd.ExecuteNonQuery();
                        mySqlUpd.Close();
                        mySql.Close();
                        return;
                    } catch (Exception) { }
                } catch (Exception) { }
                //driver.Close();
                //mySql.Close();
                return;
            }
        }
        static void Seleciona_Certificado(int x)
        {
            for (int i = 0; i < x; i++)
            {
                Thread.Sleep(250);
                SendKeys.SendWait("{Down}");
            }
            Thread.Sleep(250);
            SendKeys.SendWait("{Enter}");
        }
    }
}
